/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Pricing } from './components/Pricing';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { PaymentPage } from './components/PaymentPage';

export default function App() {
  const [selectedPlan, setSelectedPlan] = useState<{name: string, price: string} | null>(null);

  if (selectedPlan) {
    return (
      <PaymentPage 
        planName={selectedPlan.name} 
        price={selectedPlan.price} 
        onBack={() => setSelectedPlan(null)} 
      />
    );
  }

  return (
    <div className="min-h-screen font-sans bg-gray-50 text-gray-900 scroll-smooth">
      <Navigation />
      <main>
        <Hero />
        <About />
        <Services />
        <Pricing onSelectPlan={(name, price) => setSelectedPlan({ name, price })} />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
