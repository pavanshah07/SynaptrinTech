import { motion } from 'motion/react';
import { Search, MonitorSmartphone, Bot, BarChart3, Megaphone, Cpu } from 'lucide-react';

const services = [
  {
    title: 'Digital Marketing',
    description: 'Data-driven campaigns across social and search platforms to maximize your ROI and brand visibility.',
    icon: Megaphone,
    color: 'bg-orange-100 text-orange-600',
  },
  {
    title: 'SEO Services',
    description: 'Dominate search rankings with our comprehensive technical, on-page, and off-page SEO strategies.',
    icon: Search,
    color: 'bg-green-100 text-green-600',
  },
  {
    title: 'Web Development',
    description: 'Blazing fast, responsive, and accessible websites built with modern frameworks like React and Next.js.',
    icon: MonitorSmartphone,
    color: 'bg-blue-100 text-blue-600',
  },
  {
    title: 'AI Agent Creation',
    description: 'Custom AI conversational agents tailored to your business knowledge base for 24/7 customer support.',
    icon: Bot,
    color: 'bg-purple-100 text-purple-600',
  },
  {
    title: 'AI Tool Deployment',
    description: 'Integrate powerful AI models and tools into your existing workflows to supercharge team productivity.',
    icon: Cpu,
    color: 'bg-indigo-100 text-indigo-600',
  },
  {
    title: 'Analytics & Reporting',
    description: 'Transparent, real-time dashboards to track performance, user behavior, and campaign success.',
    icon: BarChart3,
    color: 'bg-rose-100 text-rose-600',
  },
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-sm font-bold text-blue-600 tracking-widest uppercase mb-3">Our Services</h2>
          <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Comprehensive solutions for the modern web.
          </h3>
          <p className="text-lg text-gray-600">
            From establishing your foundational web presence to deploying advanced AI systems, we provide everything you need to scale.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-shadow border border-gray-100"
              >
                <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-6 ${service.color}`}>
                  <Icon size={28} />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h4>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
