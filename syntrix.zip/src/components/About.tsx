import { motion } from 'motion/react';
import { Target, Users, Zap } from 'lucide-react';

const stats = [
  { label: 'Client Retention', value: '98%', icon: Users },
  { label: 'Traffic Increase', value: '300%+', icon: Target },
  { label: 'Project Delivery', value: '2x Faster', icon: Zap },
];

export function About() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-sm font-bold text-blue-600 tracking-widest uppercase mb-3">About Syntrix</h2>
            <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6 leading-tight">
              We engineer growth through intelligent design and data.
            </h3>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Syntrix isn't just an agency; we are your technical partners in the digital ecosystem. We specialize in bridging the gap between traditional SEO, robust web development, and the future of AI automation.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Whether you need a high-converting landing page, a full-scale digital marketing campaign, or custom AI agents to automate your customer service, we have the expertise to execute flawlessly.
            </p>
            
            <a href="#contact" className="inline-flex items-center text-blue-600 font-bold hover:text-blue-700">
              Meet the team
              <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="grid grid-cols-1 sm:grid-cols-2 gap-6"
          >
            <div className="bg-blue-50 rounded-2xl p-8 transform transition-transform hover:-translate-y-1">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white mb-6">
                <Target size={24} />
              </div>
              <h4 className="text-4xl font-bold text-gray-900 mb-2">98%</h4>
              <p className="text-gray-600 font-medium">Client Retention Rate</p>
            </div>
            
            <div className="bg-indigo-50 rounded-2xl p-8 sm:mt-12 transform transition-transform hover:-translate-y-1">
              <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white mb-6">
                <Users size={24} />
              </div>
              <h4 className="text-4xl font-bold text-gray-900 mb-2">500+</h4>
              <p className="text-gray-600 font-medium">Global Clients Served</p>
            </div>
            
            <div className="bg-purple-50 rounded-2xl p-8 transform transition-transform hover:-translate-y-1">
              <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center text-white mb-6">
                <Zap size={24} />
              </div>
              <h4 className="text-4xl font-bold text-gray-900 mb-2">3x</h4>
              <p className="text-gray-600 font-medium">Average ROI Increase</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
