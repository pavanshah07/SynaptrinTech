import { motion } from 'motion/react';
import { Check } from 'lucide-react';

const tiers = [
  {
    name: 'Growth',
    description: 'Perfect for small businesses looking to establish their online presence.',
    price: '₹8999',
    period: '/month',
    features: [
      'Basic Web Maintenance',
      'Local SEO Optimization',
      'Social Media Management (2 platforms)',
      'Monthly Performance Report',
      'Standard Support',
    ],
    cta: 'Buy Now',
    popular: false,
  },
  {
    name: 'Scale',
    description: 'Advanced solutions with AI integration for growing companies.',
    price: '₹19,999',
    period: '/month',
    features: [
      'Advanced Web Development',
      'National SEO Strategy',
      'Full Digital Marketing Campaign',
      'Basic AI Chatbot Integration',
      'Bi-weekly Strategy Calls',
      'Priority Support',
    ],
    cta: 'Buy Now',
    popular: true,
  },
  {
    name: 'All Packages Included',
    description: 'Custom digital ecosystems and dedicated AI agent development.',
    price: '₹24,999',
    period: '/month',
    features: [
      'Custom Full-Stack Web Apps',
      'International SEO & Localization',
      'Omnichannel Marketing Strategy',
      'Custom AI Agent Development',
      'Custom Internal AI Tools',
      '24/7 Dedicated Support',
    ],
    cta: 'Buy Now',
    popular: false,
  },
];

interface PricingProps {
  onSelectPlan: (planName: string, price: string) => void;
}

export function Pricing({ onSelectPlan }: PricingProps) {
  return (
    <section id="pricing" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-sm font-bold text-blue-600 tracking-widest uppercase mb-3">Subscriptions</h2>
          <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Simple, transparent pricing.
          </h3>
          <p className="text-lg text-gray-600">
            Choose the perfect subscription plan to accelerate your digital growth. No hidden fees.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {tiers.map((tier, index) => (
            <motion.div
              key={tier.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative rounded-3xl p-8 xl:p-10 ${
                tier.popular
                  ? 'bg-blue-600 text-white shadow-xl shadow-blue-200 border-2 border-blue-600'
                  : 'bg-white text-gray-900 border border-gray-200 shadow-sm'
              }`}
            >
              {tier.popular && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <span className="bg-gradient-to-r from-blue-400 to-indigo-400 text-white text-xs font-bold uppercase tracking-wider py-1 px-3 rounded-full">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="mb-8">
                <h4 className={`text-2xl font-bold mb-2 ${tier.popular ? 'text-white' : 'text-gray-900'}`}>{tier.name}</h4>
                <p className={`text-sm ${tier.popular ? 'text-blue-100' : 'text-gray-500'}`}>{tier.description}</p>
              </div>
              
              <div className="mb-8 flex items-baseline text-5xl font-extrabold">
                {tier.price}
                <span className={`text-xl font-medium ml-1 ${tier.popular ? 'text-blue-100' : 'text-gray-500'}`}>
                  {tier.period}
                </span>
              </div>
              
              <ul className="space-y-4 mb-8">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start">
                    <Check
                      size={20}
                      className={`mr-3 flex-shrink-0 ${tier.popular ? 'text-blue-200' : 'text-blue-600'}`}
                    />
                    <span className={tier.popular ? 'text-blue-50' : 'text-gray-600'}>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button
                onClick={() => onSelectPlan(tier.name, tier.price)}
                className={`block w-full text-center py-4 rounded-xl font-bold transition-all ${
                  tier.popular
                    ? 'bg-white text-blue-600 hover:bg-gray-50'
                    : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
                }`}
              >
                {tier.cta}
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
