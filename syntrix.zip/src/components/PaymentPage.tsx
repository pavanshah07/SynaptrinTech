import { useState, FormEvent } from 'react';
import { motion } from 'motion/react';
import { CreditCard, CheckCircle, ArrowLeft, ShieldCheck } from 'lucide-react';

interface PaymentPageProps {
  planName: string;
  price: string;
  onBack: () => void;
}

export function PaymentPage({ planName, price, onBack }: PaymentPageProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handlePayment = (e: FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    // Simulate Razorpay processing delay
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
    }, 2500);
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white max-w-md w-full rounded-3xl shadow-xl p-8 text-center"
        >
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={40} />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Payment Successful!</h2>
          <p className="text-gray-600 mb-8">
            Thank you for subscribing to the {planName} plan. Your receipt has been sent to your email.
          </p>
          <button
            onClick={onBack}
            className="w-full bg-blue-600 text-white font-bold py-3.5 rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200"
          >
            Return to Home
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center text-gray-600 hover:text-blue-600 font-medium mb-8 transition-colors"
        >
          <ArrowLeft size={20} className="mr-2" />
          Back to Pricing
        </button>

        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100 flex flex-col md:flex-row">
          {/* Order Summary */}
          <div className="md:w-1/3 bg-blue-600 text-white p-8">
            <h3 className="text-xl font-bold text-blue-100 mb-2">Order Summary</h3>
            <p className="text-3xl font-extrabold mb-6">
              {price} <span className="text-lg font-normal text-blue-200">{price !== 'Custom' ? '/ month' : ''}</span>
            </p>
            <div className="border-t border-blue-500 pt-6">
              <h4 className="font-semibold mb-2">Syntrix {planName} Plan</h4>
              <p className="text-blue-100 text-sm leading-relaxed">
                You are subscribing to the {planName} tier for comprehensive digital marketing and AI solutions.
              </p>
            </div>
          </div>

          {/* Payment Form */}
          <div className="md:w-2/3 p-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-gray-900">Checkout</h2>
              <div className="flex items-center space-x-1 text-sm font-medium text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                <ShieldCheck size={16} className="text-green-600" />
                <span>Secured by Razorpay</span>
              </div>
            </div>

            <form onSubmit={handlePayment} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                <input
                  type="email"
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                  placeholder="name@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Card Information</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-gray-400">
                    <CreditCard size={18} />
                  </div>
                  <input
                    type="text"
                    required
                    pattern="\d{16}"
                    maxLength={16}
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                    placeholder="0000 0000 0000 0000"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <input
                    type="text"
                    required
                    placeholder="MM/YY"
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                  />
                  <input
                    type="text"
                    required
                    placeholder="CVV"
                    maxLength={4}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Cardholder Name</label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                  placeholder="Cardholder Name"
                />
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-all shadow-lg shadow-blue-200 mt-4 flex justify-center items-center"
              >
                {isProcessing ? (
                  <span className="animate-pulse">Processing Payment...</span>
                ) : (
                  <span>Pay {price}</span>
                )}
              </button>
              <p className="text-center text-xs text-gray-500 mt-4 flex justify-center items-center">
                Payments are processed securely via Razorpay
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
